import { RightPanel } from '../RightPanel';

export default function RightPanelExample() {
  return (
    <div className="h-[600px] w-80 border rounded-lg overflow-hidden">
      <RightPanel />
    </div>
  );
}
