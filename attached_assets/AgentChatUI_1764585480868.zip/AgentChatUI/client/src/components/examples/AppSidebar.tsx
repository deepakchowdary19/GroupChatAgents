import { AppSidebar } from '../AppSidebar';

export default function AppSidebarExample() {
  return (
    <div className="h-[600px] border rounded-lg overflow-hidden">
      <AppSidebar />
    </div>
  );
}
